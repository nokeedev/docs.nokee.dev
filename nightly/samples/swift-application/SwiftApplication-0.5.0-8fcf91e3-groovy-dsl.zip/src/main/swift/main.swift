
func main() -> Int {
	let greeter = Greeter()
	print(greeter.sayHello(name: "Alice"))
	return 0
}

_ = main()
