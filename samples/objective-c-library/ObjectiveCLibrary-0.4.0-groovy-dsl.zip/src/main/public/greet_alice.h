
@interface GreetAlice
+ (id)alloc;
- (void)sayHelloToAlice;
@end
