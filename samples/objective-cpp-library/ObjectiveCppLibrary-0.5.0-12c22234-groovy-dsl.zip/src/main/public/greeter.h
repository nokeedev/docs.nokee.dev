
#include <string>

@interface Greeter
+ (id)alloc;
- (std::string)sayHello:(std::string)name;
@end
