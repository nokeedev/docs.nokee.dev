plugins {
	id("dev.nokee.c-library")
	id("dev.nokee.xcode-ide")
}
