plugins {
	id("java-library")
}

description = "The library for loading the shared library from the classpath or JAR."
