
public class Greeter {
	public init() {}
	public func sayHello(name: String) -> String {
		return "Bonjour, " + name + "!";
	}
}
