plugins {
	id("dev.nokee.swift-library")
	id("dev.nokee.xcode-ide")
}
