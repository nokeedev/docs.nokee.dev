pluginManagement {
	repositories {
		gradlePluginPortal()
		maven { url = uri("https://repo.nokee.dev/release") }
	}
}

rootProject.name = "gradle-plugin-development-with-test-suites"
