plugins {
	id("dev.nokee.objective-c-ios-application")
	id("dev.nokee.objective-c-xctest-test-suite")
	id("dev.nokee.xcode-ide")
}

group = "com.example"
