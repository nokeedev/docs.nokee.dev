plugins {
	id("dev.nokee.c-application")
	id("dev.nokee.xcode-ide")
}
