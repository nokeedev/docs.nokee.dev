
#include <stdio.h>
#include "greeter.h"

int main(int argc, char** argv) {
	printf("%s\n", say_hello("Alice"));
	return 0;
}
