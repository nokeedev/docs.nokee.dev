plugins {
	id("java")
	id("dev.nokee.jni-library")
	id("dev.nokee.c-language")
}
