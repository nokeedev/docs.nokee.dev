rootProject.name = "gradle-plugin-development-with-testing-strategies"
