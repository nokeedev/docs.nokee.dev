plugins {
	id("dev.gradleplugins.gradle-plugin-development") version("1.1")
}

rootProject.name = "gradle-plugin-development-runtime-compatibilities"
