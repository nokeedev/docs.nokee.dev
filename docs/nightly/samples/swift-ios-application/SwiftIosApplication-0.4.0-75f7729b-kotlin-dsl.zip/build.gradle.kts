plugins {
	id("dev.nokee.swift-ios-application")
	id("dev.nokee.xcode-ide")
}

group = "com.example"
