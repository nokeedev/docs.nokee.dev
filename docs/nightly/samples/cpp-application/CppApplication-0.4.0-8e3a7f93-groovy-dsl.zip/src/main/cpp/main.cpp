
#include <iostream>
#include "greeter.h"

int main(int argc, char* argv[]) {
	std::cout << say_hello("Alice") << std::endl;
	return 0;
}
