
#pragma once

#include <string.h>

char * say_hello(const char * name);
