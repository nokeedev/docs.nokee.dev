
#include "greeter.h"

#include <string>

std::string say_hello(std::string name) {
	return "Bonjour, " + name + "!";
}
