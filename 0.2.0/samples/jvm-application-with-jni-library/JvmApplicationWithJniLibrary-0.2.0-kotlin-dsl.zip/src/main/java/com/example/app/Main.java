
package com.example.app;

import com.example.greeter.Greeter;

public class Main {
	public static void main(String[] args) {
		System.out.println(new Greeter().sayHello("World"));
	}
}
