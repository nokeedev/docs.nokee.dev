plugins {
	id("dev.nokee.cpp-library")
	id("dev.nokee.xcode-ide")
}
