plugins {
	id("dev.nokee.cpp-application")
	id("dev.nokee.xcode-ide")
}
