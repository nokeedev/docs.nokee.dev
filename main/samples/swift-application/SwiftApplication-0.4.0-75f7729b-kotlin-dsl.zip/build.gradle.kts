plugins {
	id("dev.nokee.swift-application")
	id("dev.nokee.xcode-ide")
}
