rootProject.name = "gradle-plugin-development-with-test-suites"
