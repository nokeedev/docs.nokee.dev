pluginManagement {
	repositories {
		gradlePluginPortal()
		maven { url = uri("https://repo.nokeedev.net/release") }
	}
}

rootProject.name = "gradle-plugin-development-with-test-suites"
