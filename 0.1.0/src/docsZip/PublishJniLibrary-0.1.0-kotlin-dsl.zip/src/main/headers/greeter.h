
#pragma once

#include <string>

std::string say_hello(std::string name);
