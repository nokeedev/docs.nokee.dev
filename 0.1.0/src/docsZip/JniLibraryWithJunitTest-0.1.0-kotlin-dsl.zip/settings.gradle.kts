pluginManagement {
	repositories {
		gradlePluginPortal()
		maven {
			url = uri("https://dl.bintray.com/nokeedev/distributions-snapshots")
		}
	}
	resolutionStrategy {
		eachPlugin {
			if (requested.id.id.startsWith("dev.nokee.")) {
				useModule("${requested.id.id}:${requested.id.id}.gradle.plugin:0.1.0")
			}
		}
	}
}

rootProject.name = "jni-library-with-junit-test"
