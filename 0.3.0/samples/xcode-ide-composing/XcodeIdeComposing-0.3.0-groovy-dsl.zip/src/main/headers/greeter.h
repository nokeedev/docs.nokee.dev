
@interface Greeter
+ (id)alloc;
- (char *)sayHello:(const char *)name;
@end
